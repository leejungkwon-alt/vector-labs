"""회귀 테스트: (1) PG 풀 생성 인자, (2) 내부 500 에도 CORS 헤더가 붙는지."""
import contextlib

import pytest
from fastapi.testclient import TestClient


def test_pg_pool_constructor_args(monkeypatch):
    """os.environ.get(..., check=...) 같은 잘못된 인자 위치로 TypeError 가 나던 버그 방지."""
    import psycopg_pool
    from app.auth import repository as repo_mod

    captured = {}

    class _Cur:
        def fetchone(self):
            return {"ok": 1}  # language_code 컬럼 존재 -> ALTER 생략

    class _Conn:
        def execute(self, *a, **k):
            return _Cur()

    class FakePool:
        check_connection = staticmethod(lambda conn: None)

        def __init__(self, conninfo=None, **kwargs):
            captured["conninfo"] = conninfo
            captured.update(kwargs)

        @contextlib.contextmanager
        def connection(self):
            yield _Conn()

        def close(self):
            pass

    monkeypatch.setattr(psycopg_pool, "ConnectionPool", FakePool)
    monkeypatch.setenv("SAJU_DB_POOL_MIN", "2")
    repo_mod.PostgresRepository("postgresql://u:p@localhost/db")

    assert captured["min_size"] == 2
    assert captured["max_size"] == 5
    assert captured["max_idle"] == 60
    assert captured["check"] is FakePool.check_connection
    assert captured["kwargs"]["prepare_threshold"] is None


def test_internal_500_still_has_cors_headers(monkeypatch):
    """DB 가 죽어도 브라우저가 'CORS 에러' 가 아니라 진짜 500 JSON 을 받아야 한다."""
    from app.main import app
    from app.auth import repository as repo_mod

    def boom():
        raise RuntimeError("db down")

    monkeypatch.setattr(repo_mod, "get_repository", boom)
    import app.auth.router as router_mod
    monkeypatch.setattr(router_mod, "get_repository", boom)

    origin = "https://gyeol-blond.vercel.app"
    with TestClient(app, raise_server_exceptions=False) as c:
        r = c.post("/api/v1/auth/anonymous", headers={"Origin": origin})
    assert r.status_code == 500
    assert r.headers.get("access-control-allow-origin") in (origin, "*")
    assert r.json()["detail"] == "Internal server error."
    assert "x-request-id" in r.headers
