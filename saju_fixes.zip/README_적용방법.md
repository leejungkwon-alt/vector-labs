# 적용 방법 (프로젝트 루트에서)

1. `git add -A && git commit -m "before fixes"` (또는 폴더 백업)
2. 이 폴더의 `apply_fixes.py`, `middleware.py.new`, `tests/` 를 프로젝트 루트에 복사
3. `python apply_fixes.py --check`  → 바뀔 파일 목록 확인
4. `python apply_fixes.py`          → 적용 (제자리 수정, 여러 번 실행해도 안전)
5. `python -m pytest tests -q`     → 테스트 (새 테스트 2개 포함)
6. 백엔드 재배포:  `.\deploy.ps1`  (Cloud Run)
7. 프런트 재배포:  git push (Vercel 자동 빌드)

# 정리 (선택, 배포와 무관)
`python cleanup_repo.py` (dry-run) → 목록 확인 → `python cleanup_repo.py --apply`
